using System.Collections;
using UnityEngine;

namespace Panel
{
    public class PanelValueButton : MonoBehaviour
    {
        public enum ButtonAction
        {
            Increase,
            Decrease,
            Apply
        }

        [Header("Target")]
        [SerializeField]
        private PanelValueControl valueControl;

        [Header("Action")]
        [SerializeField]
        private ButtonAction action;


        // ==================================================
        // VISUAL
        // ==================================================

        [Header("Visual")]

        [SerializeField]
        private SpriteRenderer buttonRenderer;

        [SerializeField]
        private Sprite normalSprite;

        [SerializeField]
        private Sprite pressedSprite;

        [Min(0f)]
        [SerializeField]
        private float pressedDuration = 2f;


        private Coroutine visualCoroutine;


        // ==================================================
        // START
        // ==================================================

        private void Start()
        {
            // ���� Renderer �� ������,
            // ������� ����� ��� � ����� �������.
            if (buttonRenderer == null)
            {
                buttonRenderer =
                    GetComponent<SpriteRenderer>();
            }

            // ���� normalSprite �� ��������,
            // ���������� ������� ��������.
            if (buttonRenderer != null &&
                normalSprite == null)
            {
                normalSprite =
                    buttonRenderer.sprite;
            }
        }


        // ==================================================
        // CLICK
        // ==================================================

        private void OnMouseDown()
        {
            Debug.Log(
                $"[VALUE BUTTON CLICK] {name} -> {action}"
            );


            if (valueControl == null)
            {
                Debug.LogError(
                    $"[{name}] PanelValueControl �� ��������!"
                );

                return;
            }


            switch (action)
            {
                case ButtonAction.Increase:

                    Debug.Log(
                        $"[{name}] Increase"
                    );

                    valueControl.Increase();

                    break;


                case ButtonAction.Decrease:

                    Debug.Log(
                        $"[{name}] Decrease"
                    );

                    valueControl.Decrease();

                    break;


                case ButtonAction.Apply:

                    Debug.Log(
                        $"[{name}] APPLY -> " +
                        $"{valueControl.CurrentValue}"
                    );

                    // ������� ��������� ��������.
                    valueControl.Apply();

                    // � ������ ����� ������ ��������.
                    ShowPressedVisual();

                    break;
            }
        }


        // ==================================================
        // VISUAL
        // ==================================================

        private void ShowPressedVisual()
        {
            // ������ ������ ����� �� ������
            // �� ������ Apply.
            if (buttonRenderer == null)
            {
                Debug.LogWarning(
                    $"[{name}] Button Renderer �� ��������. " +
                    $"Apply �� ����� ��������."
                );

                return;
            }


            if (pressedSprite == null)
            {
                Debug.LogWarning(
                    $"[{name}] Pressed Sprite �� ��������. " +
                    $"Apply �� ����� ��������."
                );

                return;
            }


            buttonRenderer.sprite =
                pressedSprite;


            if (visualCoroutine != null)
            {
                StopCoroutine(
                    visualCoroutine
                );
            }


            visualCoroutine =
                StartCoroutine(
                    ResetVisual()
                );
        }


        private IEnumerator ResetVisual()
        {
            yield return new WaitForSeconds(
                pressedDuration
            );


            if (buttonRenderer != null &&
                normalSprite != null)
            {
                buttonRenderer.sprite =
                    normalSprite;
            }


            visualCoroutine = null;
        }
    }
}