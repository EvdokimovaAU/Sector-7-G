using System.Collections;
using UnityEngine;

namespace Panel
{
    public class PanelButton : PanelElement
    {
        // ==================================================
        // BUTTON SETTINGS
        // ==================================================

        [Header("Button Settings")]

        [Tooltip("���� true � ������ ������������� ����� 0 � 1.")]
        [SerializeField]
        private bool isTwoState = true;

        [SerializeField]
        private bool isOn = false;


        // ==================================================
        // BUTTON VISUAL
        // ==================================================

        [Header("Button Visual")]

        [SerializeField]
        private SpriteRenderer targetRenderer;

        [SerializeField]
        private Sprite spriteNormal;

        [SerializeField]
        private Sprite spritePressed;


        // ==================================================
        // INDICATOR
        // ==================================================

        [Header("Indicator")]

        [SerializeField]
        private SpriteRenderer indicatorRenderer;

        [SerializeField]
        private Sprite indicatorOffSprite;

        [SerializeField]
        private Sprite indicatorOnSprite;


        // ==================================================
        // AUTO RESET
        // ==================================================

        [Header("Auto Reset")]

        [SerializeField]
        private bool autoReset = false;

        [SerializeField]
        private float autoResetDelay = 0.2f;


        // ==================================================
        // INSTABILITY
        // ==================================================

        [Header("Instability")]

        [SerializeField]
        private PanelInstabilityManager instabilityManager;


        private Coroutine resetCoroutine;


        // ==================================================
        // UNITY
        // ==================================================

        private void Start()
        {
            if (instabilityManager == null)
            {
                instabilityManager =
                    FindAnyObjectByType<PanelInstabilityManager>();
            }

            RefreshVisual();
        }


        private void OnDisable()
        {
            StopAutoReset();
        }


        // ==================================================
        // INTERACTION
        // ==================================================

        public override void Interact()
        {
            Debug.Log(
                $"[PANEL CLICK] {elementID}"
            );


            // ==================================================
            // ��������������� ������
            // ==================================================

            if (isTwoState)
            {
                isOn = !isOn;

                RefreshVisual();

                SendAction();

                return;
            }


            // ==================================================
            // ������� ������
            // ==================================================

            isOn = true;

            RefreshVisual();

            SendAction();


            if (autoReset)
            {
                StartAutoReset();
            }
        }


        // ==================================================
        // GET VALUE
        //
        // ��� ABSTRACT-����� �� PanelElement
        // ==================================================

        public override int GetValue()
        {
            if (isTwoState)
            {
                return isOn ? 1 : 0;
            }


            // ������� ������ ��� �������
            // ������ ���������� 1.
            return 1;
        }


        // ==================================================
        // REFRESH VISUAL
        //
        // ��� ABSTRACT-����� �� PanelElement
        // ==================================================

        protected override void RefreshVisual()
        {
            // ------------------------------
            // �������� ����� ������
            // ------------------------------

            if (targetRenderer != null)
            {
                if (isOn)
                {
                    if (spritePressed != null)
                    {
                        targetRenderer.sprite =
                            spritePressed;
                    }
                }
                else
                {
                    if (spriteNormal != null)
                    {
                        targetRenderer.sprite =
                            spriteNormal;
                    }
                }
            }


            // ------------------------------
            // �������� / ���������
            // ------------------------------

            if (indicatorRenderer != null)
            {
                if (isOn)
                {
                    if (indicatorOnSprite != null)
                    {
                        indicatorRenderer.sprite =
                            indicatorOnSprite;
                    }
                }
                else
                {
                    if (indicatorOffSprite != null)
                    {
                        indicatorRenderer.sprite =
                            indicatorOffSprite;
                    }
                }
            }
        }


        // ==================================================
        // SEND ACTION
        // ==================================================

        private void SendAction()
        {
            int value =
                GetValue();


            PanelElementID actualID =
                GetActualElementID();


            Debug.Log(
                $"[PANEL BUTTON] " +
                $"Pressed: {elementID} | " +
                $"Actual action: {actualID} | " +
                $"Value: {value}"
            );


            PanelEvents.ElementChanged(
                actualID,
                value
            );
        }


        // ==================================================
        // INSTABILITY
        // ==================================================

        private PanelElementID GetActualElementID()
        {
            // ���� ��������� ��� �
            // �� �������� ��� ������.

            if (instabilityManager == null)
            {
                return elementID;
            }


            PanelElementID actualID =
                elementID;


            // ==================================================
            // �������� �������
            //
            // < 80:
            // Generator
            // Pump
            // ReactorSection
            //
            // < 60:
            // Reset <-> WaterSupply
            //
            // EmergencyShutdown � ReactorMode
            // �������� �� ��������.
            // ==================================================

            actualID =
                instabilityManager
                    .GetActualButtonID(actualID);


            // ==================================================
            // TURBINE
            //
            // < 60:
            //
            // Turbine1 <-> Turbine1_Stop
            // Turbine2 <-> Turbine2_Stop
            // ==================================================

            actualID =
                instabilityManager
                    .GetActualTurbineID(actualID);


            return actualID;
        }


        // ==================================================
        // SET STATE
        // ==================================================

        public void SetState(
            bool newState,
            bool sendEvent = false)
        {
            isOn = newState;

            RefreshVisual();


            if (!sendEvent)
            {
                return;
            }


            SendAction();
        }


        // ==================================================
        // AUTO RESET
        // ==================================================

        private void StartAutoReset()
        {
            StopAutoReset();


            resetCoroutine =
                StartCoroutine(
                    AutoResetRoutine()
                );
        }


        private void StopAutoReset()
        {
            if (resetCoroutine == null)
            {
                return;
            }


            StopCoroutine(
                resetCoroutine
            );

            resetCoroutine = null;
        }


        private IEnumerator AutoResetRoutine()
        {
            yield return new WaitForSeconds(
                autoResetDelay
            );


            isOn = false;

            RefreshVisual();


            // �����:
            // PanelEvents ����� �� ��������.
            //
            // ����� ����� ������� 1
            // ����� 0.2 ��� ���� ������� ��� � 0.


            resetCoroutine = null;
        }
    }
}