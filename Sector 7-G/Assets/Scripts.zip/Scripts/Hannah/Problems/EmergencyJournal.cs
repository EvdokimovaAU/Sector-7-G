using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class EmergencyJournal : MonoBehaviour
{
    // =========================================================
    // BOOK
    // =========================================================

    [Header("Book")]

    [SerializeField]
    private GameObject journalWindow;


    // =========================================================
    // LEFT PAGE
    // =========================================================

    [Header("Left Page")]

    [SerializeField]
    private TMP_Text titleText;

    [SerializeField]
    private TMP_Text descriptionText;

    [SerializeField]
    private TMP_Text sectorText;

    [SerializeField]
    private TMP_Text phoneText;


    // =========================================================
    // RIGHT PAGE
    // =========================================================

    [Header("Right Page")]

    [Tooltip(
        "������� ������ ����� �� Hierarchy: " +
        "Step1, Step2, Step3, Step4."
    )]
    [SerializeField]
    private List<EmergencyJournalStepUI> stepItems = new();


    // =========================================================
    // NAVIGATION
    // =========================================================

    [Header("Navigation")]

    [SerializeField]
    private Button previousButton;

    [SerializeField]
    private Button nextButton;

    [SerializeField]
    private TMP_Text pageNumberText;


    // =========================================================
    // JOURNAL PAGES
    // =========================================================

    [Header("Journal Pages")]

    [SerializeField]
    private List<EmergencyJournalPage> pages = new();


    // =========================================================
    // CURRENT EMERGENCY
    // =========================================================

    [Header("Current Emergency")]

    [SerializeField]
    private TaskTriggeredEmergency emergency;


    // =========================================================
    // RUNTIME
    // =========================================================

    private int currentPageIndex = 0;


    // =========================================================
    // UNITY
    // =========================================================


    private void Start()
    {
        currentPageIndex = 0;

        RefreshPage();


        // ��� ������� ���� ����� �������.
        if (journalWindow != null)
        {
            journalWindow.SetActive(false);
        }
    }


    private void OnEnable()
    {
        SubscribeToEmergency();
    }


    private void OnDisable()
    {
        UnsubscribeFromEmergency();
    }


   


    // =========================================================
    // EMERGENCY EVENTS
    // =========================================================

    private void SubscribeToEmergency()
    {
        if (emergency == null)
            return;


        emergency.OnEmergencyStarted +=
            HandleEmergencyChanged;

        emergency.OnEmergencyProgressChanged +=
            HandleEmergencyChanged;

        emergency.OnEmergencyResolved +=
            HandleEmergencyChanged;
    }


    private void UnsubscribeFromEmergency()
    {
        if (emergency == null)
            return;


        emergency.OnEmergencyStarted -=
            HandleEmergencyChanged;

        emergency.OnEmergencyProgressChanged -=
            HandleEmergencyChanged;

        emergency.OnEmergencyResolved -=
            HandleEmergencyChanged;
    }


    private void HandleEmergencyChanged()
    {
        RefreshPage();
    }


    // =========================================================
    // OPEN / CLOSE
    // =========================================================

    public void OpenJournal()
    {
        if (journalWindow == null)
        {
            Debug.LogError(
                "[EmergencyJournal] Journal Window �� ��������."
            );

            return;
        }


        if (UIWindowManager.Instance != null)
        {
            UIWindowManager.Instance.OpenWindow(
                journalWindow
            );
        }
        else
        {
            journalWindow.SetActive(true);
        }


        RefreshPage();
    }


    public void CloseJournal()
    {
        if (journalWindow == null)
            return;


        if (UIWindowManager.Instance != null)
        {
            UIWindowManager.Instance.CloseWindow(
                journalWindow
            );
        }
        else
        {
            journalWindow.SetActive(false);
        }
    }


    public void ToggleJournal()
    {
        if (journalWindow == null)
        {
            Debug.LogError(
                "[EmergencyJournal] Journal Window �� ��������."
            );

            return;
        }


        bool shouldOpen =
            !journalWindow.activeSelf;


        journalWindow.SetActive(
            shouldOpen
        );


        if (shouldOpen)
        {
            RefreshPage();
        }
    }


    // =========================================================
    // NAVIGATION
    // =========================================================

    public void NextPage()
    {
        if (pages == null ||
            pages.Count == 0)
        {
            return;
        }


        currentPageIndex++;


        if (currentPageIndex >= pages.Count)
        {
            currentPageIndex = 0;
        }


        RefreshPage();
    }


    public void PreviousPage()
    {
        if (pages == null ||
            pages.Count == 0)
        {
            return;
        }


        currentPageIndex--;


        if (currentPageIndex < 0)
        {
            currentPageIndex =
                pages.Count - 1;
        }


        RefreshPage();
    }


    // =========================================================
    // REFRESH PAGE
    // =========================================================

    private void RefreshPage()
    {
        if (pages == null ||
            pages.Count == 0)
        {
            ClearPage();
            return;
        }


        if (currentPageIndex < 0 ||
            currentPageIndex >= pages.Count)
        {
            currentPageIndex = 0;
        }


        EmergencyJournalPage page =
            pages[currentPageIndex];


        // -------------------------
        // TITLE
        // -------------------------

        if (titleText != null)
        {
            titleText.text =
                page.Title;
        }


        // -------------------------
        // DESCRIPTION
        // -------------------------

        if (descriptionText != null)
        {
            descriptionText.text =
                page.Description;
        }


        // -------------------------
        // SECTOR
        // -------------------------

        if (sectorText != null)
        {
            sectorText.text =
                "���: " +
                page.Sector.ToString();
        }


        // -------------------------
        // PHONE
        // -------------------------

        if (phoneText != null)
        {
            phoneText.text =
                "�������: " +
                page.PhoneNumber;
        }


        // -------------------------
        // STEPS
        // -------------------------

        RefreshSteps(page);


        // -------------------------
        // PAGE NUMBER
        // -------------------------

        if (pageNumberText != null)
        {
            pageNumberText.text =
                $"{currentPageIndex + 1} / {pages.Count}";
        }


        // -------------------------
        // NAVIGATION BUTTONS
        // -------------------------

        bool hasSeveralPages =
            pages.Count > 1;


        if (previousButton != null)
        {
            previousButton.interactable =
                hasSeveralPages;
        }


        if (nextButton != null)
        {
            nextButton.interactable =
                hasSeveralPages;
        }
    }


    // =========================================================
    // REFRESH STEPS
    // =========================================================

    private void RefreshSteps(
        EmergencyJournalPage page)
    {
        if (stepItems == null)
            return;


        // ��������/������� ������ ����������
        // ������ ����:
        //
        // 1. ������ ������ ���� �������� ������.
        // 2. �������� �������� ��������� ������
        //    � ���� ������.
        bool isCurrentEmergency =
            emergency != null &&
            emergency.IsActive &&
            page.EmergencyID ==
            emergency.EmergencyID;


        for (int i = 0;
             i < stepItems.Count;
             i++)
        {
            EmergencyJournalStepUI item =
                stepItems[i];


            if (item == null)
                continue;


            // ���� �� �������� ������ �����,
            // ��� ������� UI-�����,
            // ������ ������ ��������� ��������.
            if (page.Steps == null ||
                i >= page.Steps.Count)
            {
                item.gameObject.SetActive(false);
                continue;
            }


            // ������ ���������� ����� ������.
            item.gameObject.SetActive(true);


            bool completed =
                IsStepCompleted(
                    page,
                    i
                );


            // ���������� ����� � ��������
            // ������ ������� / �������.
            item.Setup(
                page.Steps[i],
                completed
            );


            // � ��� ��������� ����������
            // ������ � ������� ������.
            item.SetCheckmarkVisible(
                isCurrentEmergency
            );
        }
    }


    // =========================================================
    // CHECK COMPLETED STEP
    // =========================================================

    private bool IsStepCompleted(
        EmergencyJournalPage page,
        int stepIndex)
    {
        if (emergency == null)
            return false;


        // ��� �������� ������.
        if (!emergency.IsActive)
            return false;


        // ������� �������� ������ ������.
        if (page.EmergencyID !=
            emergency.EmergencyID)
        {
            return false;
        }


        // ��������:
        //
        // CompletedStepCount = 2
        //
        // Step 0 = ��������
        // Step 1 = ��������
        // Step 2 = �� ��������
        return stepIndex <
               emergency.CompletedStepCount;
    }


    // =========================================================
    // CLEAR PAGE
    // =========================================================

    private void ClearPage()
    {
        if (titleText != null)
        {
            titleText.text = "";
        }


        if (descriptionText != null)
        {
            descriptionText.text = "";
        }


        if (sectorText != null)
        {
            sectorText.text = "";
        }


        if (phoneText != null)
        {
            phoneText.text = "";
        }


        if (pageNumberText != null)
        {
            pageNumberText.text = "";
        }


        if (stepItems == null)
            return;


        foreach (
            EmergencyJournalStepUI item
            in stepItems)
        {
            if (item != null)
            {
                item.gameObject.SetActive(false);
            }
        }
    }

    // =========================================================
    // RANDOM EMERGENCY
    // =========================================================

    public EmergencyJournalPage GetRandomEmergencyPage()
    {
        if (pages == null ||
            pages.Count == 0)
        {
            Debug.LogError(
                "[EmergencyJournal] " +
                "� Pages ��� ������."
            );

            return null;
        }


        int randomIndex =
            Random.Range(
                0,
                pages.Count
            );


        EmergencyJournalPage page =
            pages[randomIndex];


        Debug.Log(
            $"[JOURNAL RANDOM] " +
            $"������� ������: " +
            $"{page.EmergencyID}"
        );


        return page;
    }
}